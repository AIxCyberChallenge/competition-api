#! /bin/sh

cleanup() {
	exit 0
}

trap cleanup EXIT

dockerd -H tcp://127.0.0.1:2375 --tls=false
